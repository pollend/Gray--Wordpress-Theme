		<div id="footer">
			&copy;<?php echo date("Y"); echo " "; bloginfo('name'); ?>
			<div>
				designed and built by: <a id="company-logo" href="http://baseplatedesigns.com/">Base Plate</a>

			</div>
		</div>

	</div>

	<?php wp_footer(); ?>
	
	<!-- Don't forget analytics -->
	
</body>

</html>
