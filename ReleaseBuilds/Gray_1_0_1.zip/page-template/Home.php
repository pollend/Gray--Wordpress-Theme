<?php 
/**
 * Template Name: Front Page Template
 */
?>

<?php
define('WP_USE_THEMES', true);
 get_header(); ?>

<?php  get_template_part( 'Presentation', 'index' ); ?>
<?php get_footer(); ?>
