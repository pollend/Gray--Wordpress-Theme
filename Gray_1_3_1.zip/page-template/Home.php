<?php 
/**
 * Template Name: Front Page Template
 */
?>

<?php
 get_header(); ?>

<?php  get_template_part( 'Presentation', 'index' ); ?>
<?php get_footer(); ?>
