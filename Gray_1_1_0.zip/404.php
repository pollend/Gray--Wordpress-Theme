<?php get_header(); ?>
<div class="entry">

	<img class="alignnone" src="<?php  echo get_template_directory_uri(). "/images/404.png"; ?>">
		<h3 style="text-align:center;">would you like to try and search for something else?</h3><div style="width:500px;margin:0px auto;padding:0px"><?php get_search_form(); ?></div>


<?php get_footer(); ?>