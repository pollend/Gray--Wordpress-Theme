<form action="<?php echo home_url(); ?>" id="searchForm" method="get">
        <label for="s" class="screen-reader-text">Search for:</label>
        <input type="text" id="s" name="s" value="" />
        
        <input type="submit" value="" id="searchsubmit" />
</form>